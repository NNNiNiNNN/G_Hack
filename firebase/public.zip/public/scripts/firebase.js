// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
var firebaseConfig = {
  apiKey: "AIzaSyALYb-gpwW_8i8HyA9cXAMKBynobmDBV4I",
  authDomain: "g-hack-project.firebaseapp.com",
  databaseURL: "https://g-hack-project.firebaseio.com",
  projectId: "g-hack-project",
  storageBucket: "g-hack-project.appspot.com",
  messagingSenderId: "82020781735",
  appId: "1:82020781735:web:e2feed88dfa4cb7e171582"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();
